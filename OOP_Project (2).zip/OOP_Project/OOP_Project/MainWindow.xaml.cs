﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace OOP_Project
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public AddTransaction addTrans = new AddTransaction();
        public MainWindow mainWinOne;
        public AddJewelry addJewelOne;

        public MainWindow()
        {
            Background = Brushes.SeaGreen;
            InitializeComponent();
        }
        private void btnInventory_Click(object sender, RoutedEventArgs e)
        {
            addJewelOne.Show();
            //this.Hide();
        }

        private void btnAddTransaction_Click(object sender, RoutedEventArgs e)
        {
            addTrans.Show();
            //this.Hide();
        }
    }
}
