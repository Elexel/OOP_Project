﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace OOP_Project
{
    /// <summary>
    /// Interaction logic for AddJewelry.xaml
    /// </summary>
    public partial class AddJewelry : Window
    {
        AddTransaction addTransA = new AddTransaction();
        Product jewelry = new Product();

        public AddJewelry()
        {
            Background = Brushes.SeaGreen;
            InitializeComponent();
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            int quantity = Convert.ToInt32(txtQuantity.Text);

            jewelry.Items = quantity;

            this.Close();
            
        }

        private void cmbType_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
