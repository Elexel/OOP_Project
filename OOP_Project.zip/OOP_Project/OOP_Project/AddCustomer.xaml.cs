﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace OOP_Project
{
    /// <summary>
    /// Interaction logic for AddCustomer.xaml
    /// </summary>
    public partial class AddCustomer : Window
        
    {
        public DataStorage data;
        public Person customer;
        public MainWindow mainWinThree;
        public AddCustomer()
        {
            Background = Brushes.SeaGreen;
            InitializeComponent();
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            Person customer = new Person(txtFirstName.Text, txtLastName.Text, txtMiddleName.Text);
            AddTransaction addTransThree = new AddTransaction();


            //this code checks if the name the user entered exists in customers list
            bool exist = false;
            foreach(Person cust in data.customers)
            {
                if (customer.GetFullName() == cust.GetFullName())
                {
                    exist = true;
                    break;
                }
            }
            if (!exist) // if it does not exist, add it to the storage
            {
                data.customers.Add(customer);
            }
            else // if it exists, show a message and then exit
            {
                MessageBox.Show("The name you have entered already exist in the system");
            }
            this.Close();
        }

        private void txtFirstName_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
